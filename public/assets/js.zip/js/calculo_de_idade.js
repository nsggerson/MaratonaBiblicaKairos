//Calculo de idade 
function calculationOfAge() {
    //Data atual
    var dateNow = new Date();
    var dia = parseInt(dateNow.getDate());
    var mes = parseInt(dateNow.getMonth()) + 1;
    var ano = parseInt(dateNow.getFullYear());
    //Data de nascimento
    var x = document.getElementById("inputData").value;
    var date = x.split('-');
    var yyyy = parseInt(date[0]);
    var mm = parseInt(date[1]);
    var dd = parseInt(date[2]);
    //Validado a indade com o mês
    if (mes === mm & dia === dd) {
        var anoidade = ano - yyyy;
        document.getElementById("inputIdade").value = anoidade;
    } else {
        var anoidade = ano - yyyy;
        document.getElementById("inputIdade").value = anoidade - 1;
    }
}