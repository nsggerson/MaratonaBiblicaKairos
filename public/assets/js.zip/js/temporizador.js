"use strict"
var tempo = 1000;
var cron;
var ss = 00;

$(function start() {
    cron = setInterval(() => { timer(); }, tempo);
});

function stop() {
    clearInterval(cron);
}

function timer() {
    ss++;
    if (ss == 30) {
        this.stop();
    }
    var format = (ss < 10 ? '0' + ss : ss);
    // document.getElementById('counter').innerText = format;
    document.body.onload = adcElemento;


    // cria um novo elemento div 
    // e dá à ele conteúdo
    var divNova = document.createElement("div");
    var conteudoNovo = document.createTextNode(format);
    divNova.appendChild(conteudoNovo); //adiciona o nó de texto à nova div criada 

    // adiciona o novo elemento criado e seu conteúdo ao DOM 
    var divAtual = document.getElementById("div1");
    document.body.insertBefore(divNova, divAtual);

}