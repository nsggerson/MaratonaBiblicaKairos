//alert('input_create_setor')
var rulers = {
    //Position 0
    name: {
        'type': 'string',
        'required': true,
        'sizeMin': '3',
        'sizeMax': '25'
    },
    //Position 2
    rh: {
        'type': 'int',
        'sizeMin': '5',
        'sizeMax': '10'
    },
    //Position 3
    idade: {
        'type': 'int',
        'sizeMin': '1',
        'sizeMax': '3'
    },

    etiniagenero: {
        'type': 'options'
    }
};