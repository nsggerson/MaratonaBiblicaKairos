var array = [];
var aut = false;
array[0] = document.getElementById('frEstressInjuria');
array[1] = document.getElementById('aj');
array[2] = document.getElementById('cb');
array[3] = document.getElementById('cp');
array[4] = document.getElementById('pct');
array[5] = document.getElementById('cpant');
array[6] = document.getElementById('ftAtvalor');
array[7] = document.getElementById('diagnostico');
//array[6] = document.getElementById('peso');
//array[7] = document.getElementById('altura');

function equipamento(str) {

    var tm = array.length;
    for (let a = 0; a < tm; a++) {

        for (let b = 2; b < tm; b++) {
            const forward = array[b];

            if (validarform(str)) {
                if (str.id === array[0].id) {
                    this.fatorEstresse(str.value);
                    array[1].readOnly = false;
                    array[1].focus();
                }
                str.style.borderColor = "green";
                document.getElementById('authentic-' + str.id).style.display = 'inline';
                forward.readOnly = false;
                forward.focus();
                c = b - 1;
                // Ativando a função imc
                if (array[c].value && array[b].value && document.getElementById('imc').value.length < 1) {
                    this.calculoPesoEstimado();
                    this.calculoAlturaEstimado();
                    this.calculation_imc();
                }

                //                               
                if (forward.id === 'ftAtvalor') {
                    document.querySelector("table").style.display = '';
                    document.getElementById('error').innerHTML = 'Defina o campo F.A com os valores da tabela abaixo.';
                    document.getElementById('error').style.color = 'blue';
                }
                //  Configurando o campo diagnostico
                if (array[b].id == 'diagnostico' && array[b].value.length > 1) {
                    var diagnostico = [];
                    var e;
                    var exploder = String(array[b].value).split('');
                    for (let d = 0; d < exploder.length; d++) {
                        const element = exploder[d];
                        diagnostico[d] = element.replace(' ', '/');
                    }
                    // Desativando o painel 
                    document.querySelector("table").style.display = 'none';
                    e = diagnostico.join('');
                    array[b].value = e.toUpperCase();
                    document.getElementById('gravar').focus();
                }
            } else {
                // Configurando input no Erro
                document.getElementById('authentic-' + str.id).style.display = 'none';
                str.style.borderColor = "red";
                str.focus();
                return false;
            }
            //  Verifica se o proximo valor de array tem valor se não para.
            if (forward.value == null || forward.value === '') {
                return false;
            }
        }
    }
    this.aut = true;
}

function authenticate() {
    var diagnostico = avaliacao.diagnostico.value;

    if (document.getElementById('frEstressInjuria').value === '&') {
        document.getElementById('error').style.color = 'red';
        document.getElementById('error').innerHTML = 'O campo fator Estresse não pode conter o valor (Escolha...)';
        return false;
    }
    if (this.aut == false) {
        document.getElementById('error').innerHTML = '';
        document.querySelector("table").style.display = '';
        return false;
    }
    return this.aut;
}