var rulers = {
    setor: {
        'type': 'options'
    },
    andar: {
        'type': 'options'
    },
    leito: {
        'type': 'options'
    }
};