var rulers = {
    //Position 0

    rh: {
        'required': true,
        'type': 'int',
        'sizeMin': '4',
        'sizeMax': '7'
    },
    setor: {
        'type': 'options'
    }
};