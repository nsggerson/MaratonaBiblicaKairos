//inputDeambulante
//alert('Ok regras do input foi acessado!');
var rulers = {

    //Position 0
    rh: {
        'type': 'int',
        'required': true,
        'sizeMin': '4',
        'sizeMax': '5'

    }
};