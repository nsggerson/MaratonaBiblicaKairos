function internar(str) {
    var rh = document.getElementById('rh');
    var setor = document.getElementById('setor');

    if (validarform(rh)) { true; return };
    if (validarform(setor)) { true; return };

    return false;
}