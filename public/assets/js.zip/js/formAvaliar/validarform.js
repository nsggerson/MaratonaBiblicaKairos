var caracter = {
    numbers: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, '.', ','],
    string: ['/', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
        'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
        'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', ' ', 'ã', 'Ã', 'ç', 'Ç', 'é', 'É', 'ã', 'Ã', 'í', 'Í'
    ],
    varchar: ['/', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
        'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
        'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', ' ', 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 'é', 'É', 'ã', 'Ã'
    ]
};
/*
$( "#peso").change(function() {
      alert( "Handler for .change() called." );
    });*/


function errors(nameCamp, type, param) {
    var name = String(nameCamp.id).toUpperCase();
    var tipo = String(type).toUpperCase();
    var text = type === 'sizeMin' ? 'minimo' || type === 'sizeMax' : 'Maximo';
    switch (type) {
        case 'required':
            document.getElementById('error').innerHTML = "O campo " + name + " é requerido.";
            return false;
        case 'sizeMin':
            document.getElementById('error').innerHTML = "O campo " + name + " precisa conter um " + text + " de " + param + ' Caracters';
            return;
        case 'sizeMax':
            document.getElementById('error').innerHTML = "O campo " + name + " precisa conter um " + text + " de " + param + ' Caracters';
            return false;
        case 'list':
            document.getElementById('error').innerHTML = "Campo com valores já definidos na tabela, utilize um dos valores.";
            return false;
        case 'float':
            document.getElementById('error').innerHTML = "O campo " + name + " só recebe valores do tipo " + tipo;
            return false;
        case 'string':
            document.getElementById('error').innerHTML = "O campo " + name + " só recebe valores do tipo " + tipo;
            return false;
        case 'varchar':
            document.getElementById('error').innerHTML = "O campo " + name + " só recebe valores do tipo " + tipo;
            return false;
        case 'int':
            document.getElementById('error').innerHTML = "O campo " + name + " só recebe valores do tipo " + tipo;
            return false;
        default:
            document.getElementById('error').innerHTML = "";
            return true;
    }
}

function validate(param) {
    var tm = Object.keys(rulers[param.id]).length;
    for (let a = 0; a < tm; a++) {
        const element = Object.keys(rulers[param.id])[a];
        switch (element) {
            case 'required':
                if (param.value.length < 1) {
                    return errors(param, 'required', null);
                }
                document.getElementById('error').innerHTML = "";
                break;
            case 'sizeMin':
                if (param.value.length < rulers[param.id].sizeMin) {
                    return errors(param, 'sizeMin', rulers[param.id].sizeMin);
                }
                document.getElementById('error').innerHTML = "";
                break;
            case 'sizeMax':
                if (param.value.length > rulers[param.id].sizeMax) {
                    return errors(param, 'sizeMax', rulers[param.id].sizeMax);
                }
                document.getElementById('error').innerHTML = "";
                break;
            case 'list':
                var valido = 'no';
                var pm = String(param.value).replace(',', '.');
                var list = rulers[param.id].list;
                var array = String(list).split(',');
                for (let b = 0; b < array.length; b++) {
                    const elementList = array[b];
                    if (pm === elementList) { valido = 'yes'; break; }
                }
                if (valido === 'no') {
                    return errors(param, 'list', null);
                }
                document.getElementById('error').innerHTML = '';
                break;
            default:
                break;
        }
    }
    document.getElementById('error').innerHTML = "";
    return true;
}
// Função principal
function validarform(str) {
    //alert(str.id)
    type = rulers[str.id].type;

    switch (type) {
        case 'float':
            if (validateTypeFloat(str) === 'yes') {
                return this.validate(str);
            } else { return errors(str, 'float', null); }
        case 'string':
            if (validateTypeString(str) === 'yes') {
                return this.validate(str);
            } else { return errors(str, 'string', null); }
        case 'int':
            if (validateTypeInt(str) === 'yes') {
                return this.validate(str);
            } else { return errors(str, 'int', null); }
        case 'varchar':
            if (validateTypeVarchar(str) === 'yes') {
                return this.validate(str);
            } else { return errors(str, 'string', null); }
        case 'options':
            //alert('Utilizando valida form')
            if (str.value != 'null') {
                return true
            } else { alert('É preciso escolher um ' + str.id + ' !'); return false }

        default:
            return false;
    }
}

function validateTypeFloat(param) {
    if (param.value === '0') {
        document.getElementById('error').innerHTML = " O campo não pode receber valor do tipo (0)";
        return 'no';
    }
    var array = param.value.split('');
    var tm = caracter.numbers.length;
    for (let a = 0; a < array.length; a++) {
        c = 0
        const firtElement = array[a];

        while (true) {
            if (firtElement == caracter.numbers[c]) { break; }
            if (c >= tm) { return 'no'; }
            c++;
        }
    }
    return 'yes';
}

function validateTypeString(param) {
    var array = param.value.split('');
    var tm = caracter.string.length;
    for (let a = 0; a < array.length; a++) {
        c = 0
        const firtElement = array[a];
        while (true) {
            if (firtElement == caracter.string[c]) { break; }
            if (c >= tm) { return 'no'; }
            c++;
        }
    }
    return 'yes';
}

function validateTypeVarchar(param) {
    var array = param.value.split('');
    var tm = caracter.varchar.length;
    for (let a = 0; a < array.length; a++) {
        c = 0
        const firtElement = array[a];
        while (true) {
            if (firtElement == caracter.varchar[c]) { break; }
            if (c >= tm) { return 'no'; }
            c++;
        }
    }
    return 'yes';
}

function validateTypeInt(param) {
    if (param.value === '0') {
        document.getElementById('error').innerHTML = " O campo não pode receber valor do tipo (0)";
        return 'no';
    }
    var array = param.value.split('');
    var tm = caracter.numbers.length;
    for (let a = 0; a < array.length; a++) {
        c = 0
        const firtElement = array[a];
        while (true) {
            if (firtElement === '.' || firtElement === ',') { return 'no'; }
            if (firtElement == caracter.numbers[c]) { break; }
            if (c >= tm) { return 'no'; }
            c++;
        }
    }
    return 'yes';
}