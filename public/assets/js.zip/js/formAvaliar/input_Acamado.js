//alert('input')
var rulers = {
    //Position 0
    frEstressInjuria: {
        'type': 'options'
    },

    aj: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'

    },
    //Position 1
    cb: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 2
    cp: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 3
    pct: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 4
    cpant: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },

    //Position 5
    pesoHab: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },


    //Position 5
    diagnostico: {
        'type': 'string',
        'sizeMin': '2',
        'sizeMax': '20'
    },

    //Position 3
    prescrito: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },

    //Position 3
    infundido: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },

    //Position 3
    calorico: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },


};