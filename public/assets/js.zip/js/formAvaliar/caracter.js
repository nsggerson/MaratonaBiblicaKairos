var int = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
var float = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, ',', '.'];
var caracteres = ['.', ','];

var string = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k',
    'l', 'm', 'n', 'o', 'p', 'q', 'r', 't', 'w', 'x', 'y', 'z', ' ', '/', '.'
];

var text = [];