//inputDeambulante

var rulers = {

    //Position 0
    frEstressInjuria: {
        'type': 'options'
    },
    peso: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'

    },
    //Position 1
    altura: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 2
    cb: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 3
    cp: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 4
    pct: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 5
    cpant: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 6
    diagnostico: {
        'type': 'string',
        'sizeMin': '2',
        'sizeMax': '20'
    },

};