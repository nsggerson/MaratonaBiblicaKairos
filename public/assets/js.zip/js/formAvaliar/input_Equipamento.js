var rulers = {
    //Position 0
    frEstressInjuria: {
        'type': 'options'
    },
    //Position 0
    aj: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'

    },
    //Position 1
    cb: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 2
    cp: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 3
    pct: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 4 
    cpant: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5'
    },
    //Position 5
    ftAtvalor: {
        'type': 'float',
        'sizeMin': '2',
        'sizeMax': '5',
        'list': [1.2, 1.25, 1.3]
    },
    //Position 6
    diagnostico: {
        'type': 'string',
        'sizeMin': '2',
        'sizeMax': '20'
    }
};