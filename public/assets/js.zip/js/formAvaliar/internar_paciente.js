function validar() {
    var setor = document.getElementById('setor');
    if (validarform(setor)) {
        var andar = document.getElementById('andar');
        var leito = document.getElementById('leito');
        if (validarform(andar)) {
            if (validarform(leito)) {
                return true;
            }
        }
    }
    return false;

}