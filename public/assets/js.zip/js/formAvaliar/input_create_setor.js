//alert('input_create_setor')
var rulers = {
    //Position 0
    setor: {
        'type': 'string',
        'required': true,
        'sizeMin': '3',
        'sizeMax': '10'
    },
    //Position 2
    andar: {
        'type': 'varchar',
        'sizeMin': '1',
        'sizeMax': '10'
    },
    //Position 3
    leito: {
        'type': 'int',
        'sizeMin': '1',
        'sizeMax': '4'
    }
};