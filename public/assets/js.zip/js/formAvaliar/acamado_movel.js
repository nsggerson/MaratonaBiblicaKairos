var array = [];
var aut = false;
array[0] = document.getElementById('frEstressInjuria');
array[1] = document.getElementById('aj');
array[2] = document.getElementById('cb');
array[3] = document.getElementById('cp');
array[4] = document.getElementById('pct');
array[5] = document.getElementById('cpant');
array[6] = document.getElementById('diagnostico');

function acamado_movel(str) {
    var tm = array.length;
    for (let a = 0; a < tm; a++) {
        for (let b = 2; b < tm; b++) {
            const forward = array[b];
            if (validarform(str)) {
                c = b - 1; // Pega a posição anterior
                if (str.id === array[0].id) {
                    this.fatorEstresse(str.value);
                    array[1].readOnly = false;
                    array[1].focus();
                }
                str.style.borderColor = "green";
                document.getElementById('authentic-' + str.id).style.display = 'inline';
                forward.readOnly = false;
                forward.focus();
                //c = b - 1;
                // Ativando a função imc
                if (array[c].value && array[b].value && document.getElementById('imc').value == '0,00') {
                    this.calculoPesoEstimado();
                    this.calculoAlturaEstimado();
                    this.calculation_imc();
                }
                //  Configurando o campo diagnostico
                if (array[b].id == 'diagnostico' && array[b].value.length > 1) {
                    var diagnostico = [];
                    var e;
                    var exploder = String(array[b].value).split('');
                    for (let d = 0; d < exploder.length; d++) {
                        const element = exploder[d];
                        diagnostico[d] = element.replace(' ', '/');
                    }
                    e = diagnostico.join('');
                    array[b].value = e.toUpperCase();
                    document.getElementById('gravar').focus();
                }
            } else {
                // Configurando input no Erro
                document.getElementById('authentic-' + str.id).style.display = 'none';
                str.style.borderColor = "red";
                str.focus();
                return false;
            }
            //  Verifica se o proximo valor de array tem valor se não para.
            if (forward.value == null || forward.value === '') {
                return false;
            }
        }
    }
    this.aut = true;
}

function authenticate() {
    var diagnostico = avaliacao.diagnostico.value;
    if (document.getElementById('frEstressInjuria').value === '&') {
        document.getElementById('error').innerHTML = 'O campo fator Estresse não pode conter o valor (Escolha...)';
        return false;
    }
    if (this.aut == false) {
        document.getElementById('error').innerHTML = '';
        return false;
    }
}